# Thermodynamic-Mind
A zero-logic ecosystem where 100 agents must evolve "habits" to survive computational energy scarcity. Proving General Intelligence through thermodynamic efficiency.
